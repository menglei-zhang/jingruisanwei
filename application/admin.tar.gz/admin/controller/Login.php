<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\RoleModel;
use app\admin\model\UserModel;
use think\Cache;
use think\Controller;
use org\Verify;

class Login extends Controller
{
    // 登录页面
    public function index()
    {
        if(!session('username')){
            $token = cookie('token');

            if($token){
                $data = Cache::get($token);

                if($data) {
                    session('username', $data['user_name']);
                    session('user_id', $data['user_id']);
                    session('head', $data['head']);
                    session('role', $data['role_name']);  // 角色名
                    session('role_id', $data['role_id']);
                    session('rule', $data['rule']);

                    return $this -> redirect(url('admin/index/index'));
                }
            }
        } else {
            return $this -> redirect(url('admin/index/index'));
        }

        return $this->fetch('/login');
    }

    // 登录操作
    public function doLogin()
    {
        $userName = input("param.user_name");
        $password = input("param.password");
        $code = input("param.code");
        $free = input('param.free', 0);

        $result = $this->validate(compact('userName', 'password', "code"), 'AdminValidate');
        if(true !== $result){
            return json(msg(-1, '', $result));
        }

        $verify = new Verify();
        if (!$verify->check($code)) {
            return json(msg(-2, '', '验证码错误'));
        }

        $userModel = new UserModel();
        $hasUser = $userModel->checkUser($userName);

        if(empty($hasUser)){
            return json(msg(-3, '', '管理员不存在'));
        }

        if(md5($password . config('salt')) != $hasUser['password']){
            return json(msg(-4, '', '密码错误'));
        }

        if(1 != $hasUser['status']){
            return json(msg(-5, '', '该账号被禁用'));
        }
        // var_dump($hasUser);exit;
        session('username', $hasUser['user_name']);
        session('user_id', $hasUser['user_id']);    
        session('head', $hasUser['head']);
        session('role', $hasUser['role_name']);  // 角色名
        session('role_id', $hasUser['role_id']);
        session('rule', $hasUser['rule']);

        // 更新管理员状态
        $param = [
            'login_times' => $hasUser['login_times'] + 1,
            'last_login_ip' => request()->ip(),
            'last_login_time' => time()
        ];

        $res = $userModel->updateStatus($param, $hasUser['user_id']);
        

        if(1 != $res['code']){
            return json(msg(-6, '', $res['msg']));
        }
        // ['code' => 1, 'data' => url('index/index'), 'msg' => '登录成功']

        if($free){
            $sign = sha1(random_num($hasUser['user_id']));
            $token = sha1(str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT) . uniqid() . $sign);

            Cache::set($token, $hasUser, 86400 * 7);
            cookie('token', $token, 86400 * 7);
        }


        return json(msg(1, url('index/index'), '登录成功'));
    }

    // 验证码
    public function checkVerify()
    {
        $verify = new Verify();
        $verify->imageH = 32;
        $verify->imageW = 100;
        $verify->length = 4;
        $verify->useNoise = false;
        $verify->fontSize = 14;
        return $verify->entry();
    }

    // 退出操作
    public function loginOut()
    {
        session('username', null);
        session('id', null);
        session('head', null);
        session('role', null);  // 角色名
        session('role_id', null);
        session('rule', null);

        $token = cookie('token');
        Cache::rm($token);
        cookie('token', null);

        $this->redirect(url('index'));
    }
}
