<?php
/**
 * Created by PhpStorm.
 * User: Rain
 * Date: 2019/7/2
 * Time: 15:28
 */

namespace app\admin\model;


use think\Model;

class NoticeModel extends Model
{
    // 确定链接表名
    protected $name = 'notice';
}