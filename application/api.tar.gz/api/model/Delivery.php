<?php
/**
 * Created by PhpStorm.
 * User: Rain
 * Date: 2019/1/19
 * Time: 10:34
 */

namespace app\index\model;


use think\Model;

class Delivery extends Model
{

}