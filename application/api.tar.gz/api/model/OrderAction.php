<?php
/**
 * Created by IntelliJ IDEA.
 * User: xmiao
 * Date: 2019/1/7
 * Time: 1:52
 */

namespace app\index\model;

use think\model;
class OrderAction extends model
{

}