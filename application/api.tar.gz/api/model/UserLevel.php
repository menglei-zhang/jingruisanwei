<?php
/**
 * Created by PhpStorm.
 * User: Rain
 * Date: 2019/1/17
 * Time: 13:27
 */

namespace app\index\model;


use think\Model;

class UserLevel extends Model
{

}