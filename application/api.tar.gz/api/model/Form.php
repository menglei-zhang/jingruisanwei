<?php
/**
 * Created by PhpStorm.
 * User: Rain
 * Date: 2019/6/10
 * Time: 15:37
 */

namespace app\api\model;


use think\Model;

class Form extends Model
{

}